import random
# In this game you can set difficulty of the game to easy (5 attempts) or
# hard(10 attempts) and then start guess numbers.

guessing_number = random.randint(1, 100)

easy_level = 10
hard_level = 5

"""Function to check users answer against guessing number and return number of attempts remaining"""
def check_number(users_guess, guessing_number, guess_limit):
    if users_guess > guessing_number:
        print("Too high.")
        # Track the number of turns and reduce 1 if they got it wrong
        return guess_limit - 1
    elif users_guess < guessing_number:
        print("Too low.")
        return guess_limit - 1
    else:
        print(f"You got it. The answer was {guessing_number}.")

"""Function to set difficulty, 5 attempts = hard, 10 attempts = easy"""
def easy_or_hard():
    choise = input("Choose difficulty. Type 'easy' or 'hard'. ")
    if choise == "easy":
        return easy_level
    else:
        return hard_level

def play_game():
    print("Welcome to the Number Guessing Game!")
    print("I am thinking of a number between 1 and 100.")
    print(f"Psst. The correct answer is {guessing_number}.")
    guess_limit = easy_or_hard() # trigger function to set difficulty

# Repeat the functionality if they got it wrong
    while True:
        print(f"You have {guess_limit} attempts remaining to guess the number. ")
        # Let the user guess the number
        users_guess = int(input("Make a guess: "))
        #trigger function check_number() and refresh variable guess_limit
        guess_limit = check_number(users_guess, guessing_number, guess_limit) #pass given number to check against random number
        if users_guess == guessing_number:
            break
        elif guess_limit == 0:
            print("You have run out of guesses. You lose. ")
            break
play_game()