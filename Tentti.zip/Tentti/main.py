import pymongo

# 1) Luo yhteys Mongo DB:hen
connection = pymongo.MongoClient('localhost', 27017)

# 2) Luo tietokanta kuntavaali
db = connection.kuntavaali

# 3) Luo collection ehdokas
ehdokas = db.ehdokas

# 4) Kysy käyttäjältä ehdokkaan tiedot ja lisää ehdokas collectioniin
def create_new():
        ehdokas_numero = input("Syötä ehdokkaan numero: ")
        ehdokas_etunimi = input("Syötä ehdokkaan etunimi: ")
        ehdokas_sukunimi = input("Syötä ehdokkaan sukunimi: ")
        ehdokas_ika = input("Ehdokkaan ikä: ")
        ehdokas_puolue = input("Ehdokkaan puolue: ")

# 5) Talleta ehdokkaiden tiedot collectioniin ehdokas - Muuta etunimen ja sukunimen ensimmäinen kirjain isoksi kirjaimeksi
        uusi_ehdokas = {'Numero' : (ehdokas_numero), 'Etunimi' : (ehdokas_etunimi.capitalize()),
                        'Sukunimi' : (ehdokas_sukunimi.capitalize()),
                'Ika' : (ehdokas_ika), 'Puolue' : (ehdokas_puolue)}

# 6) Vahvistus ehdokkaan lisäämisestä. Virheen sattuessa ilmoittaa siitä.
        try:
            ehdokas.insert_one(uusi_ehdokas)
            print ('Uusi ehdokas lisätty')

        except  Exception as e:
            print( 'Unexpected error:', type(e), e)

def main():
# 7) Kysy ehdokkaiden tiedot haluttu määrä (n) ja kutsu create_new() funktio
    for i in range(3):
        create_new()
# 8) Tulostaa kaikki ehdokkaat
    results = ehdokas.find()
    print("Kaikki ehdokkaat: ")
    for x in ehdokas.find():
      print(x)

# 9) Tulostaa puolueen SDP ehdokkaat
#tulostaa kaikki autot jotka ovat make sap
    myquery = { "Puolue": "SDP" }
    print("Puolueen SDP ehdokkaat:")
    mydoc = ehdokas.find(myquery)
    for x in mydoc:
      print(x)

# 10) Sulje yhteys
    connection.close()
if __name__ == "__main__":
    main()