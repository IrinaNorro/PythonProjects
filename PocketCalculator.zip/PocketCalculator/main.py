# POCKET CALCULATOR
num_1 = float(input("Enter first number: "))
num_2 = float(input("Enter second number: "))

sum = num_1+num_2
substraction = num_1-num_2
multiplication = num_1*num_2
division = num_1/num_2

print("(1) +\n(2) -\n(3) *\n(4) /")
selection = input("Please select (1-4): ")
if selection == "1":
    print("Result is: ",sum)
elif selection == "2":
    print("Result is: ",substraction)
elif selection == "3":
    print("Result is: ",multiplication)
elif selection == "4":
    print("Result is: ",division)
else:
   print("Unknown selection.")