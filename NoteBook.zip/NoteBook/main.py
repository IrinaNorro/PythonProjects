# This program is a notebook where you can add your notes, read notes and erase notes.

#ask user a question until program is ended
while True:

    file = open("notebook.txt", "r")
    print("(1) Read notebook \n(2) Add a note \n(3) Empty notebook\n(4) Quit\n")
    choise = input("What would you like to do?: ")

    #opens a file and displays content
    if choise == "1":
        sisalto = file.read()
        print(sisalto)

    #adds a note to the end of file
    elif choise == "2":
        add_note = input("Add a new note: ")
        file = open("notebook.txt", "a")
        add_to_file = add_note
        file.write(add_note +"\n")

    #overwrite notebook and close it - erases content
    elif choise == "3":
        file = open("notebook.txt", "w")
        file.close()
        print("Notebook has been emptied.")

    #close notebook and end the program
    elif choise == "4":
        file.close()
        print("Program ended.")
        break

    else:
        print("Unknown choise.")
