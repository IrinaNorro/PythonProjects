""" BLACKJACK 21 """
import random
from replit import clear


cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]


def one_card():
    """Returns one random card from a deck"""
    cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
    random_card = random.choice(cards)
    return random_card


def calculate_score(cards):
    """check Blackjack if there is, return 0"""
    if len(cards) == 2 and sum(cards) == 21:
        return 0
    """checks if there is Ace in hand and if score is over 21 changes to ace to 1"""
    if 11 in cards and sum(cards) > 21:
       cards.remove(11)
       cards.append(1)
    return sum(cards)


def compare_scores(players_score, dealers_score):
    if players_score > 21 and dealers_score > 21:
        return "You went over. You lose 😤"
    elif dealers_score == 0 and players_score == 0:
        return "You both have a Blackjack, but dealer wins, you lose."
    elif players_score == dealers_score:
        return "It's a draw."
    elif dealers_score == 0:
        return "Dealer has a Blackjack."
    elif players_score == 0:
        return "You win with Blackjack."
    elif players_score > 21:
        return "You went over. You lose."
    elif dealers_score > 21:
        return "Dealer went over. You win."
    elif players_score > dealers_score:
        return "You win."
    else:
        return "You lose"

def play_game():
    """Game starts here"""
    """ Deals two cards, adds to the list"""
    dealers_hand = []
    players_hand = []

    for card in range(2):
        players_hand.append(one_card())
        dealers_hand.append(one_card())

    is_game_over = False
    while not is_game_over:
        """Calling calculate function and calculate players and users scores"""
        players_score = calculate_score(players_hand)
        dealers_score = calculate_score(dealers_hand)
        print(f"  Your cards: {players_hand}, current score: {players_score}")
        print(f"  Computer's first card: {dealers_hand[0]}")  # [0] shows only first card

        """Check if there is Blackjack (0) or score over 21"""
        if players_score == 0 or dealers_score == 0 or players_score > 21:
            is_game_over = True

        else:
            try:

                add_another_card = input("Type 'y' to get another card or type 'n' to pass: ")
                if add_another_card == "y":
                    players_hand.append(one_card())

                elif add_another_card == "n":
                    is_game_over = True

            except IndexError:
                print("Error. Please choose again.")

    """Dealer is playing"""
    # keep dealing cards if score is not 0 meaning Blackjack and is under 17
    while dealers_score != 0 and dealers_score < 17:
        dealers_hand.append(one_card())
        dealers_score = calculate_score(dealers_hand)  # refresh dealers score

    """Compare scores after all cards are played"""
    print(f"Your final hand {players_hand}, your final score: {players_score}.")
    print(f"Dealers final hand {dealers_hand}, dealers final score: {dealers_score}")
    print(compare_scores(players_score, dealers_score))

try:

    should_continue = True
    while should_continue:
        yes =  input("Do you want to play game of Blackjack? Type 'y' or 'n'. ")
        if yes == "y":
            clear()
            play_game()

except IndexError:
    print("Error. Please choose again.")
