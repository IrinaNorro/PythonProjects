from replit import clear

bidders =  {} #empty dictionary

def find_highest_bid(): #function to find highest bid
    winner = ""
    highest_bid = None
    for bidder, value in bidders.items(): # loop through bidder and bids pairs in dictionary
        if highest_bid is None or value > highest_bid:
            highest_bid = value
            winner = bidder

    print(f"The winner is: {winner} with bid of {highest_bid} €")

should_continue = True
while should_continue:

    input_name = input("What is your name?: ")
    input_sum = int(input("What is your bid?: "))

    def add_new_bid(name, sum):

        bidders[input_name] = input_sum # add pair to dictionary

    add_new_bid(input_name, input_sum) #call funktion, pass through arguments to dictionary

    decide = input("Are there any other bidders? Type 'yes' or 'no'. ")
    if decide == "no":
        should_continue = False
        find_highest_bid() #call function that shows the highest bid

    elif decide == "yes":
        clear()

