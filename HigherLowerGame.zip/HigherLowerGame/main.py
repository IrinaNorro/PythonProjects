
import random
from game_data import data
from replit import clear

def format_data(account):
    name = account["name"]
    descr = account["description"]
    country = account["country"]
    return (f"{name}, a {descr} from {country}")

def compare(followers_a,  followers_b):
    if followers_a["follower_count"] > followers_b["follower_count"]:
        return "a"
    else:
        return "b"

def game():
    score =0
    option_a = random.choice(data)
    option_b = random.choice(data)
    should_continue = True
    while should_continue:
        option_a = option_b
        option_b = random.choice(data)
        while option_a == option_b:
            option_b = random.choice(data)
        print(f'Compare A: {format_data(option_a)}')
        print(f'Against B: {format_data(option_b)}')
        guess = input("A or B? ")

        if guess == compare(option_a, option_b):
            score += 1
            clear()
            print(f"You guessed right. Your score {score}")
        else:
            should_continue = False
            print(f"You guessed wrong, your final score {score}")
game()