"""
CALCULATOR
"""
from replit import clear
"""Go to run - edit configurations- choose 'emulate terminal in output console' for clear() to work"""

"""
Create functions for operations
"""
def add(n1, n2):
    return n1 + n2

def substract(n1, n2):
    return n1 - n2

def multiply(n1, n2):
    return n1 * n2

def divide(n1, n2):
    return n1 / n2

"""
Create dictionaries for operation symbols
"""
operations = {
    "+" : add,
    "-" : substract,
    "*" : multiply,
    "/" : divide,
}
"""Start calculation"""
def calculator():
    number1 = float(input("What's the first number?: "))
    for symbol in operations:
        print(symbol)

    """ should_continue variable is setting a flag"""
    should_continue = True
    while should_continue:

        try:
            operation_symbol = input("Pick an operation symbol: ")
            number2 = float(input("What's the next number?: "))
            """Create calculation function that passes operations and user's numbers """
            calculation_function = operations[operation_symbol]
            result = calculation_function(number1,number2)
            print(f"{number1} {operation_symbol} {number2} = {result}")

            whats_next = input(f"Type 'y' to continue calculating with {result} or type 'n' to exit or type 's' to start a new calclulation: ")

            if whats_next  == "y":
                number1 = result
            elif whats_next == "n":
                should_continue = False
            elif whats_next == "s":
                should_continue = False
                clear()
                """RECURSION = GOING BACK TO BEGINNING"""
                calculator()
            else:
                print("Invalid choice.")
                should_continue = False
        except ZeroDivisionError:
            print("Divide by 0 Error. Exit calculator.")
            should_continue = False
calculator()
