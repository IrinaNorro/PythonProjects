import pickle
import time

file_name = "notebook.dat"
list = []
#Notebook is .dat file and content is inside file as a list variable []

#tries to open an excisting file and load the excisting list
try:
    file = open(file_name, "rb")
    list = pickle.load(file)
    file.close()

#if file does not exist, creates one
except IOError:
    print("Error in loading the file. Creating a new file notebook.dat.")
    file = open(file_name, "wb")
except EOFError:
    print("Error in loading the file. Creating a new file notebook.dat.")
    file = open(file_name, "wb")
except IndexError:
    print("Error. Please choose again.")

while True:
    print("(1) Read notebook\n(2) Add a note\n(3) Edit a note \n(4) Erase a note \n(5) Save and quit\n")

    choise = int(input("What do you choose?: "))

# read Notebook - prints the list
    if choise == 1:
        for i in list:
            print(i)

# add note to the Notebook
    elif choise == 2:

        add_note = input("Write a new note: ")
        file = open(file_name, "wb")
        time_now = time.strftime("%X %x")
        note_and_time = add_note + ":::" + time_now
        list.append(note_and_time)
        pickle.dump(list, file)

# change previously added note
    elif choise == 3:
        try:
            #first choose item on a list that needs to be edited
            length = len(list)
            print(f"List has {length} notes.")
            change = int(input("Which one do you prefer to choose:"))
            change = change-1
            print(list[change])
        except IndexError:
            print("Error. Please choose again.")
        else:
            #insert new text to chosen item, save it
            new_note = input("Insert new text: ")
            time_now = time.strftime("%X %x")
            new_note_and_time_now = new_note + ":::" + time_now
            list.pop(change)
            list.insert(change, new_note_and_time_now)
            file = open(file_name, "wb")
            pickle.dump(list, file)
            file.close()

#erase chosen item from the list
    elif choise == 4:
        length = len(list)
        print(f"List has {length} notes.")
        erase = int(input("Which one will be erased?: "))
        try:
            erase = erase-1
            print(f"Erased note {list[erase]}")
            list.pop(erase)
            file = open(file_name, "wb")
            pickle.dump(list, file)
            file.close()
        except IndexError:
            print("Error. Please choose again.")

#save and close the file
    elif choise ==5:
        file = open(file_name, "wb")
        pickle.dump(list, file)
        file.close()
        print("Quit. Have a nice day.")
        break

    else:
        print("Unknown selection.")