#HANGMAN
import random
from hangman_art import stages, logo
from hangman_words import word_list
from replit import clear

#you could choose a word from a list or just write down your own word
chosen_word = random.choice(word_list)
#chosen_word = "superman"
lives = 6
#print(chosen_word)

print(logo)
#create blanks
display = ['_'] * len(chosen_word)

#Ask for a letter until user or computer wins
end_of_game = False
while not end_of_game:
    guess = input("Guess a letter: ")
    guess = guess.lower()

    clear()
#check guessed letter
    for position in range(len(chosen_word)):
        letter = chosen_word[position]
        if letter == guess:
            display[position] = letter
    print(display)
#check if there are more blanks
    if '_' not in display:
        end_of_game = True
        print("You win.")
#reduce lives if guess is incorrect
    if guess not in chosen_word:
        print(f"You guessed {guess}, that's not in a word, you lose a life.")
        lives -= 1
        if lives == 0:
            end_of_game = True
            print("You lose.")
#print picture of hangman according to how many lives left
    print(stages[lives])